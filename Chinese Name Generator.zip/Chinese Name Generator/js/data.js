// Chinese character database with meanings and pronunciations
const chineseCharacters = {
    // Common surname characters
    surnames: {
        'ma': ['马', '麦', '米'],
        'mi': ['米', '密', '迷'],
        'mai': ['麦', '迈', '脉'],
        'mu': ['穆', '牧', '慕']
        // Add more surname mappings
    },

    // Given name characters with positive meanings
    givenNames: {
        // Characters meaning brightness/intelligence
        bright: ['明', '晖', '辉', '智', '慧', '哲'],
        
        // Characters meaning strength/power
        strong: ['强', '力', '刚', '威', '武', '彪'],
        
        // Characters meaning virtue/kindness
        virtue: ['德', '仁', '义', '善', '礼', '信'],
        
        // Characters meaning beauty/elegance
        beauty: ['美', '雅', '婷', '秀', '丽', '俊'],
        
        // Characters meaning success/achievement
        success: ['成', '胜', '达', '兴', '旺', '腾']
    },

    // Pronunciation mapping rules
    pronunciationRules: {
        // Consonants
        'b': ['博', '白', '柏'],
        'c': ['才', '楚', '辰'],
        'd': ['德', '大', '东'],
        'f': ['福', '芳', '凡'],
        'g': ['高', '光', '国'],
        'h': ['海', '华', '浩'],
        'j': ['金', '建', '俊'],
        'k': ['凯', '康', '开'],
        'l': ['力', '立', '良'],
        'm': ['明', '美', '梅'],
        'n': ['宁', '南', '年'],
        'p': ['平', '鹏', '普'],
        'q': ['青', '秋', '庆'],
        'r': ['荣', '瑞', '仁'],
        's': ['思', '松', '生'],
        't': ['天', '同', '泰'],
        'w': ['文', '伟', '万'],
        'x': ['新', '祥', '晓'],
        'y': ['永', '阳', '英'],
        'z': ['志', '忠', '正']
    }
};

// Cultural meanings and interpretations
const culturalMeanings = {
    // Positive qualities often desired in names
    qualities: {
        wisdom: 'Represents intelligence and wisdom, highly valued in Chinese culture',
        strength: 'Symbolizes physical and mental strength, important for personal growth',
        virtue: 'Embodies moral excellence and good character',
        prosperity: 'Signifies success and good fortune in life',
        harmony: 'Represents balance and peace with others and nature'
    },

    // Traditional elements
    elements: {
        wood: 'Associated with growth and flexibility',
        fire: 'Represents energy and passion',
        earth: 'Symbolizes stability and reliability',
        metal: 'Associated with strength and determination',
        water: 'Represents wisdom and adaptability'
    }
};

// Export the data for use in main.js
window.nameData = {
    characters: chineseCharacters,
    meanings: culturalMeanings
};
