// API configuration
const API_CONFIG = {
    API_KEY: '80a434b611da474ba7759737893dedd7.c9h4JupZBX2GLEdq',
    API_URL: 'https://open.bigmodel.cn/api/paas/v4/chat/completions',
    MODEL: 'glm-4-flash'
};

// Template for name generation prompt
const generatePrompt = (englishName) => {
    return `作为一位精通中国传统起名文化的专家，请为英文名"${englishName}"创作3个富有文化内涵的中文名字。

遵循以下规则：
1. 姓氏选择：
- 使用常见中国姓氏（如：王、李、张、刘等）
- 尽量选择与英文名发音相近的姓氏
- 避免罕见姓氏

2. 名字构建：
- 单字名或双字名（不含姓氏）
- 选用常用汉字，避免生僻字
- 字义优美，寓意积极
- 男女性别特征明显
- 发音优美，好记易写

3. 文化内涵：
- 融入传统文化元素（如：诗词、典故）
- 体现现代积极价值观
- 名字整体和谐优雅
- 适合终身使用

请按以下JSON格式返回结果：
{
    "names": [
        {
            "chinese_name": "完整中文名",
            "pinyin": "带声调拼音",
            "meaning": "字面含义解释",
            "cultural_explanation": "文化内涵和选字理由说明",
            "personality_traits": ["暗含的性格特点"],
            "english_explanation": "简短英文说明"
        }
    ]
}

要求：
1. 名字要朗朗上口
2. 避免不雅或负面含义
3. 符合现代审美
4. 便于书写和记忆

仅返回JSON格式内容，无需其他说明。`;
};

// Function to generate JWT token
function generateToken(apiKey, expSeconds = 3600) {
    const [id, secret] = apiKey.split('.');
    
    // JWT header
    const header = {
        "alg": "HS256",
        "sign_type": "SIGN"
    };
    
    // JWT payload
    const payload = {
        "api_key": id,
        "exp": Math.floor(Date.now() / 1000) + expSeconds,
        "timestamp": Math.floor(Date.now() / 1000)
    };
    
    // Base64Url encode header and payload
    const encodeBase64Url = (obj) => {
        return btoa(JSON.stringify(obj))
            .replace(/=/g, '')
            .replace(/\+/g, '-')
            .replace(/\//g, '_');
    };
    
    const encodedHeader = encodeBase64Url(header);
    const encodedPayload = encodeBase64Url(payload);
    
    // Create signature
    const signatureInput = encodedHeader + "." + encodedPayload;
    const encoder = new TextEncoder();
    const data = encoder.encode(signatureInput);
    const secretBuffer = encoder.encode(secret);
    
    return new Promise((resolve, reject) => {
        crypto.subtle.importKey(
            "raw",
            secretBuffer,
            { name: "HMAC", hash: { name: "SHA-256" } },
            false,
            ["sign"]
        ).then(key => {
            return crypto.subtle.sign(
                "HMAC",
                key,
                data
            );
        }).then(signature => {
            const encodedSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
                .replace(/=/g, '')
                .replace(/\+/g, '-')
                .replace(/\//g, '_');
            resolve(encodedHeader + "." + encodedPayload + "." + encodedSignature);
        }).catch(reject);
    });
}

// Function to call GLM-4 API
async function callGLMAPI(prompt) {
    try {
        // Generate JWT token
        const token = await generateToken(API_CONFIG.API_KEY);
        
        const response = await fetch(API_CONFIG.API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                model: API_CONFIG.MODEL,
                messages: [
                    {
                        role: "user",
                        content: prompt
                    }
                ],
                temperature: 0.7,
                top_p: 0.95,
                max_tokens: 1500,
                stream: false
            })
        });

        if (!response.ok) {
            const errorData = await response.text();
            console.error('API Response:', errorData);
            throw new Error(`API call failed: ${response.status} - ${errorData}`);
        }

        const data = await response.json();
        console.log('API Response:', data);
        
        if (!data.choices || !data.choices[0] || !data.choices[0].message || !data.choices[0].message.content) {
            throw new Error('Invalid API response format');
        }

        return JSON.parse(data.choices[0].message.content);
    } catch (error) {
        console.error('Error calling GLM API:', error);
        throw error;
    }
}

// Main function to generate names
async function generateChineseNames(englishName) {
    try {
        const prompt = generatePrompt(englishName);
        console.log('Sending prompt:', prompt);
        const result = await callGLMAPI(prompt);
        console.log('Received result:', result);
        return result.names;
    } catch (error) {
        console.error('Error generating names:', error);
        throw error;
    }
}

// Export functions
window.nameAPI = {
    generateChineseNames
};
