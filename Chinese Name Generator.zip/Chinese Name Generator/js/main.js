// Main application logic
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const englishNameInput = document.getElementById('englishName');
    const generateBtn = document.getElementById('generateBtn');
    const resultsSection = document.getElementById('resultsSection');
    const nameTemplate = document.getElementById('nameResultTemplate');

    // Event Listeners
    generateBtn.addEventListener('click', generateNames);
    englishNameInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') generateNames();
    });

    // Main name generation function
    async function generateNames() {
        const englishName = englishNameInput.value.trim();
        if (!englishName) {
            alert('Please enter your English name');
            return;
        }

        try {
            // Show loading state
            generateBtn.disabled = true;
            generateBtn.textContent = 'Generating...';
            resultsSection.innerHTML = '<div class="loading">Generating names, please wait...</div>';

            // Call API to generate names
            const names = await window.nameAPI.generateChineseNames(englishName);
            
            // Clear previous results
            resultsSection.innerHTML = '';

            // Display each generated name
            names.forEach(nameObj => {
                displayNameResult(nameObj);
            });
        } catch (error) {
            console.error('Error generating names:', error);
            resultsSection.innerHTML = '<div class="error">Sorry, there was an error generating names. Please try again.</div>';
        } finally {
            // Reset button state
            generateBtn.disabled = false;
            generateBtn.textContent = 'Generate Names';
        }
    }

    // Display name result using template
    function displayNameResult(nameObj) {
        const template = nameTemplate.content.cloneNode(true);
        
        // Fill in the template
        template.querySelector('.chinese-name').textContent = nameObj.chinese_name;
        template.querySelector('.pinyin').textContent = nameObj.pinyin;
        
        // Create meaning section
        const meaningDiv = template.querySelector('.meaning');
        meaningDiv.innerHTML = `
            <h3>Meaning</h3>
            <p class="meaning-text">${nameObj.meaning}</p>
            <p class="english-meaning">${nameObj.english_explanation}</p>
        `;

        // Create cultural section
        const culturalDiv = template.querySelector('.cultural-notes');
        culturalDiv.innerHTML = `
            <h3>Cultural Significance</h3>
            <p class="cultural-text">${nameObj.cultural_explanation}</p>
        `;

        // Create personality traits section
        const characterDiv = template.querySelector('.character-analysis');
        characterDiv.innerHTML = `
            <h3>Personality Traits</h3>
            <div class="traits">
                ${nameObj.personality_traits.map(trait => `<span class="trait">${trait}</span>`).join('')}
            </div>
        `;

        // Add save functionality
        const saveBtn = template.querySelector('.save-btn');
        saveBtn.addEventListener('click', () => saveName(nameObj));

        resultsSection.appendChild(template);
    }

    // Save name to localStorage
    function saveName(nameObj) {
        try {
            const savedNames = JSON.parse(localStorage.getItem('savedNames') || '[]');
            savedNames.push(nameObj);
            localStorage.setItem('savedNames', JSON.stringify(savedNames));
            alert('Name saved successfully!');
        } catch (error) {
            console.error('Error saving name:', error);
            alert('Failed to save name. Please try again.');
        }
    }
});
